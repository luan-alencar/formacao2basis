import { User } from '@nuvem/angular-base';

export class Usuario implements User {
    roles: string[];
    name: string;
}
