import { Component } from '@angular/core';

@Component({
    selector: 'app-diario-erros',
    templateUrl: './diario-erros.component.html'
})
export class DiarioErrosComponent {

    constructor() { }
}
