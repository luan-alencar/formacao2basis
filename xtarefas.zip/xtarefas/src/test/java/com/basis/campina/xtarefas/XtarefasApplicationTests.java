package com.basis.campina.xtarefas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XtarefasApplicationTests {

	@Test
	void contextLoads() {
	}

}
