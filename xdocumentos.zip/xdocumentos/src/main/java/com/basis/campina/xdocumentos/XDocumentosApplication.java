package com.basis.campina.xdocumentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XDocumentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(XDocumentosApplication.class, args);
	}

}
