package com.basis.campina.xdocumentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XDocumentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
